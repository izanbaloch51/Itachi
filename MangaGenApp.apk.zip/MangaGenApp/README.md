# MangaGenApp (Android) - Hybrid APK scaffold
This repo is a **ready-to-open Android Studio project** that implements a lightweight UI APK (Kotlin) that talks to a local generator server (runs on your PC) to produce manga panels, composes pages, and exports PNG pages. 
It **does not** run heavy Stable Diffusion models on-device. Instead it's designed as the practical hybrid setup where the phone is the UI and a local PC (same LAN) runs the image generator (Flask example included).

**What I created for you here (you can download the zip and open in Android Studio):**
- `app/` - Android module (Kotlin) with MainActivity, network client, layouts, manifest, and Gradle config.
- `generator_server/` - a small Flask example server (`server.py`) that wraps a local SD pipeline (example only; you must install and configure models locally).
- `README.md` - this file with build + run instructions and important notes.

**Quick summary (important):**
- This scaffold targets **Android API level 35 (Android 15)** (required by Google Play starting Aug 31, 2025 for new apps/updates). See notes and citations in the full assistant message. citeturn0search6turn0search2

---
## How to use
1. Download and unzip `MangaGenApp.zip` and open the folder in **Android Studio** (Arctic Fox or later recommended).
2. Android Studio will download Gradle and required SDK components; you may be prompted to update the Android Gradle Plugin or Kotlin plugin. Let it sync.
3. In the `generator_server/` folder you'll find `server.py` — this is a simple Flask server that listens on port 8000 and returns generated PNG bytes. Run it on your PC with a GPU (or a cloud VM) and point the app to the server IP on your LAN (e.g. `192.168.1.10`). The app UI has a field for server IP.
4. Press **Generate** in the app to send a prompt to the server; the server should return an image that the app displays. Use **Add to page** to collect panels, **Export page** to create a merged PNG page file in app storage.

---
## Build notes & tips
- Open in Android Studio and build (Android Studio will install required Gradle/kotlin toolchain). If you need to publish, ensure `targetSdk` meets Play requirements (API 35) and follow Play Console rules. citeturn0search6
- The Flask server example is intentionally minimal; replace the generator logic with your local Stable Diffusion / LoRA deployment.
- The project uses OkHttp for networking (modern versions available on Maven Central). citeturn0search14

---
## Files of interest
- `app/src/main/java/com/example/mangagen/MainActivity.kt` — main UI and page composition logic.
- `app/src/main/java/com/example/mangagen/GeneratorClient.kt` — OkHttp client to talk to `http://<server-ip>:8000/generate`.
- `generator_server/server.py` — minimal Flask server (example).

---
## Limitations / warnings
- This APK **does not** include a full on-device Stable Diffusion engine (that would require complex on-device model conversion + large model files and device-specific optimizations).
- Building on-device inference (ONNX/TensorRT/ggml) is possible but *not* included here. If you want pure on-device, tell me and I'll produce an alternate scaffold (heavier, experimental).


## CI build (GitHub Actions)
This repo contains a GitHub Actions workflow at `.github/workflows/build-apk.yml`. To build an installable APK automatically:

1. Create a GitHub repository and push this project to the `main` branch.
2. In GitHub, open the Actions tab and run the `Build Debug APK` workflow (or push to `main`).
3. When the workflow completes, download the `MangaGen-apk` artifact from the run — it will include the debug APK (installable on Android devices).

Notes:
- The workflow builds the debug APK (signed with the Gradle debug key). If you want a release-signed APK, add your keystore to the repo secrets and modify the workflow to sign the release build.
- If the build fails due to missing Android SDK components, add `android-actions/setup-android` to the workflow or use a runner that already contains the Android SDK. See documentation for details.
