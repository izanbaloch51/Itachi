# Minimal example Flask server: receives JSON {"prompt":"..."} and returns a PNG image file bytes.
# WARNING: This is an example only. Replace the `generate_image` function with your Stable Diffusion/LoRA pipeline.
from flask import Flask, request, send_file, abort
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
import json

app = Flask(__name__)

def generate_image(prompt: str):
    # placeholder image: draw the prompt text on white background
    img = Image.new('RGB', (704, 1024), color='white')
    d = ImageDraw.Draw(img)
    d.text((20,20), 'Prompt:\n' + prompt[:300], fill=(0,0,0))
    return img

@app.route('/generate', methods=['POST'])
def generate():
    data = request.get_json(force=True)
    prompt = data.get('prompt', '') if isinstance(data, dict) else ''
    if not prompt:
        abort(400, 'prompt required')
    img = generate_image(prompt)
    buf = BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return send_file(buf, mimetype='image/png')

if __name__ == '__main__':
    # run: python server.py
    app.run(host='0.0.0.0', port=8000)
