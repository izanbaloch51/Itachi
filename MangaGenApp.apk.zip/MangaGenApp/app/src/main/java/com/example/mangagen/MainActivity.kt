package com.example.mangagen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import android.content.Context

class MainActivity : AppCompatActivity() {
    private lateinit var ipEdit: EditText
    private lateinit var promptEdit: EditText
    private lateinit var generateBtn: Button
    private lateinit var imageView: ImageView
    private val panels = mutableListOf<Bitmap>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ipEdit = findViewById(R.id.ipEdit)
        promptEdit = findViewById(R.id.promptEdit)
        generateBtn = findViewById(R.id.generateBtn)
        imageView = findViewById(R.id.imageView)
        val addBtn = findViewById<Button>(R.id.addBtn)
        val exportBtn = findViewById<Button>(R.id.exportBtn)

        generateBtn.setOnClickListener {
            val ip = ipEdit.text.toString().trim()
            val prompt = promptEdit.text.toString().trim()
            if (ip.isEmpty() || prompt.isEmpty()) {
                Toast.makeText(this,"Enter server IP and prompt",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val bitmap = GeneratorClient.generatePanel(this@MainActivity, ip, prompt)
                if (bitmap != null) {
                    imageView.setImageBitmap(bitmap)
                    Toast.makeText(this@MainActivity,"Generated",Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@MainActivity,"Failed to generate",Toast.LENGTH_SHORT).show()
            }
        }

        addBtn.setOnClickListener {
            val drawable = imageView.drawable
            if (drawable == null) { Toast.makeText(this,"No image to add",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val bm = (imageView.drawable as android.graphics.drawable.BitmapDrawable).bitmap
            panels.add(bm.copy(bm.config ?: Bitmap.Config.ARGB_8888, true))
            Toast.makeText(this,"Added to page (${panels.size})",Toast.LENGTH_SHORT).show()
        }

        exportBtn.setOnClickListener {
            lifecycleScope.launch {
                if (panels.isEmpty()) { Toast.makeText(this@MainActivity,"No panels to export",Toast.LENGTH_SHORT).show(); return@launch }
                val page = withContext(Dispatchers.Default) { composePage(panels) }
                val path = withContext(Dispatchers.IO) { saveBitmapToFile(page) }
                Toast.makeText(this@MainActivity,"Saved page: $path",Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun composePage(panels: List<Bitmap>): Bitmap {
        // simple grid: 2 columns
        val cols = 2
        val panelW = 1200
        val panelH = 1600
        val rows = (panels.size + cols - 1) / cols
        val pageW = cols * panelW
        val pageH = rows * panelH
        val page = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(page)
        canvas.drawColor(android.graphics.Color.WHITE)
        val paint = android.graphics.Paint()
        var i = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (i >= panels.size) break
                val bm = Bitmap.createScaledBitmap(panels[i], panelW, panelH, true)
                val left = c * panelW
                val top = r * panelH
                canvas.drawBitmap(bm, left.toFloat(), top.toFloat(), paint)
                i++
            }
        }
        return page
    }

    private fun saveBitmapToFile(bmp: Bitmap): String {
        val dir = getExternalFilesDir("MangaPages") ?: filesDir
        dir?.mkdirs()
        val file = java.io.File(dir, "page_\${System.currentTimeMillis()}.png")
        java.io.FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
        return file.absolutePath
    }
}
